package com.majd.kitchen;
import android.content.*;
public class RestoreReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){Bookings.restore(c);Sync.plan(c);} }
