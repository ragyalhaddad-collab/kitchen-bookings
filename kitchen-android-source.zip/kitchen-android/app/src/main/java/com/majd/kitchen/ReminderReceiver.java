package com.majd.kitchen;
import android.app.*;import android.content.*;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if("ack".equals(i.getAction())){AlarmQueue.advance(c,i.getStringExtra("key"));return;}AlarmQueue.daily(c);if(Bookings.prefs(c).getLong("alarm_next",0)>System.currentTimeMillis()){AlarmQueue.kick(c);return;}AlarmQueue.start(c);}
}
