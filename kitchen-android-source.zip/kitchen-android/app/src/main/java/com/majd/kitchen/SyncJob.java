package com.majd.kitchen;
import android.app.job.*;
public class SyncJob extends JobService {
 @Override public boolean onStartJob(JobParameters p){if(!Sync.enabled(this)||Sync.busy)return false;Sync.run(this,m->jobFinished(p,!m.startsWith("✓")));return true;}
 @Override public boolean onStopJob(JobParameters p){return true;}
}
