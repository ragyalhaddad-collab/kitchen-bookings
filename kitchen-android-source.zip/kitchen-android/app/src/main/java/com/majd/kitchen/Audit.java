package com.majd.kitchen;
import android.app.*;import android.content.*;import android.os.Build;import org.json.*;import java.util.*;import java.text.*;
final class Audit {
 static JSONArray read(Context c,String key){try{return new JSONArray(Bookings.prefs(c).getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
 static JSONArray pending(Context c){return read(c,"audit_pending");}
 static String now(){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
 static String format(String value){if(value.isEmpty()||value.equals("null"))return "غير مسجل";try{String s=value.replace('T',' ');if(s.length()>=19)s=s.substring(0,19);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.US).format(d);}catch(Exception e){return value;}}
 static String action(String a){switch(a){case "create":return "إضافة حجز";case "edit":return "تعديل حجز";case "delete":return "حذف إلى الأرشيف";case "restore":return "استرجاع حجز";default:return a;}}
 static String actor(JSONObject o,String field){String s=o.optString(field,"").trim();return s.isEmpty()?"غير مسجل":s;}
 static JSONObject payload(JSONObject o)throws JSONException{JSONObject data=new JSONObject();for(String f:new String[]{"name","phone","order","date","notes","price","hour","minute","deleted","revision","created_by","created_at","last_actor","last_action","last_at","deleted_by","deleted_at"})if(o.has(f))data.put(f,o.get(f));return data;}
 static JSONObject find(Context c,String uid){JSONArray a=Bookings.load(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&uid.equals(o.optString("uid")))return o;}return null;}
 static void record(Context c,JSONObject item,JSONObject previous,String operation,String employee)throws Exception{
  if(employee.trim().isEmpty())throw new IllegalArgumentException("اسم الموظف مطلوب");
  String at=now();item.put("last_actor",employee).put("last_action",operation).put("last_at",at).put("revision",UUID.randomUUID().toString()).put("dirty",true);
  if(operation.equals("create"))item.put("created_by",employee).put("created_at",at);
  if(operation.equals("delete"))item.put("deleted_by",employee).put("deleted_at",at);
  if(operation.equals("restore")){item.remove("deleted_by");item.remove("deleted_at");}
  JSONArray a=Bookings.load(c),q=pending(c);boolean found=false;
  for(int i=0;i<a.length();i++)if(item.getString("uid").equals(a.getJSONObject(i).optString("uid"))){a.put(i,item);found=true;break;}
  if(!found)a.put(item);
  JSONObject event=new JSONObject().put("booking_id",item.getString("uid")).put("revision",item.getString("revision")).put("action",operation).put("actor",employee).put("device_time",at).put("before_data",previous==null?JSONObject.NULL:payload(previous)).put("after_data",payload(item));q.put(event);
  if(!Bookings.prefs(c).edit().putString("items",a.toString()).putString("audit_pending",q.toString()).commit())throw new java.io.IOException("تعذر حفظ العملية");
 }
 static void acknowledge(Context c,JSONArray server,Set<String> sent)throws JSONException{JSONArray q=pending(c),remaining=new JSONArray();for(int i=0;i<q.length();i++){JSONObject e=q.getJSONObject(i);if(!sent.contains(e.optString("revision")))remaining.put(e);}Bookings.prefs(c).edit().putString("audit_pending",remaining.toString()).putString("audit_remote",server.toString()).commit();}
 static List<JSONObject> history(Context c,String uid){ArrayList<JSONObject> result=new ArrayList<>();JSONArray[] arrays={read(c,"audit_remote"),pending(c)};Set<String> seen=new HashSet<>();for(JSONArray arr:arrays)for(int i=0;i<arr.length();i++){JSONObject e=arr.optJSONObject(i);if(e==null||(!uid.isEmpty()&&!uid.equals(e.optString("booking_id"))))continue;if(seen.add(e.optString("booking_id")+":"+e.optString("revision")))result.add(e);}result.sort((x,y)->y.optString("recorded_at",y.optString("device_time")).compareTo(x.optString("recorded_at",x.optString("device_time"))));return result;}
 static void notifyNew(Context c,JSONObject o){try{NotificationManager n=c.getSystemService(NotificationManager.class);if(Build.VERSION.SDK_INT>=24&&!n.areNotificationsEnabled())return;String title="حجز جديد • مطبخ المجد",detail=o.optString("name")+" — "+o.optString("order")+"\nالتسليم: "+o.optString("date")+"\nالموظف: "+actor(o,"created_by");int id=-o.optInt("id",1);PendingIntent p=PendingIntent.getActivity(c,id,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,Bookings.channel(c)):new Notification.Builder(c).setSound(Bookings.sound(c).isEmpty()?null:android.net.Uri.parse(Bookings.sound(c))).setDefaults(Notification.DEFAULT_VIBRATE).setPriority(Notification.PRIORITY_HIGH);n.notify(id,b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(detail).setStyle(new Notification.BigTextStyle().bigText(detail)).setVisibility(Notification.VISIBILITY_PRIVATE).setContentIntent(p).setAutoCancel(true).build());}catch(Exception ignored){}}
}
