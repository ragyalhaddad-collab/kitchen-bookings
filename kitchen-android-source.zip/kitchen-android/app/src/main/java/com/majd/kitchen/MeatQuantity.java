package com.majd.kitchen;
import java.math.BigDecimal;
final class MeatQuantity {
 static boolean valid(BigDecimal n,int i){return i>=0&&i<5&&n.signum()>0&&n.compareTo(new BigDecimal("999999"))<=0&&n.stripTrailingZeros().scale()<=(i<=2?3:0)&&(i>=2||n.remainder(new BigDecimal("0.25")).signum()==0);}
}
