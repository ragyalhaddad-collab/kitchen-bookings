package com.majd.kitchen;
import java.math.BigDecimal;import java.util.*;import org.json.*;
final class Meats {
 static final String[] KEYS={"oven_chicken","mandi_chicken","meat_kg","turkey_thigh","turkey_drumstick"};
 static final String[] LABELS={"جاج فرن","جاج مندي","لحمة كيلو","فخد حبش","دبوس حبش"};
 static String custom(String name,boolean kg){return (kg?"custom_kg:":"custom_n:")+name.trim().replaceAll("\\s+"," ");}
 static boolean isCustom(String k){return k.startsWith("custom_kg:")||k.startsWith("custom_n:");}
 static String label(String k){int i=Arrays.asList(KEYS).indexOf(k);return i>=0?LABELS[i]:isCustom(k)?k.substring(k.indexOf(':')+1):k;}
 static String unit(String k){return k.equals(KEYS[2])||k.startsWith("custom_kg:")?"كيلو":"عدد";}
 static boolean valid(BigDecimal v,String k){int i=Arrays.asList(KEYS).indexOf(k);return MeatQuantity.valid(v,i>=0?i:k.startsWith("custom_kg:")?2:3);}
 static String format(BigDecimal v){return v.stripTrailingZeros().toPlainString();}
 static BigDecimal qty(JSONObject item,String k){if(item==null)return BigDecimal.ZERO;JSONObject m=item.optJSONObject("meat_qty");if(m==null)return BigDecimal.ZERO;try{BigDecimal v=new BigDecimal(m.optString(k,"0"));return v.signum()>0?v:BigDecimal.ZERO;}catch(Exception e){return BigDecimal.ZERO;}}
 static void collect(Set<String> keys,JSONObject item){if(item==null)return;JSONObject m=item.optJSONObject("meat_qty");if(m!=null){Iterator<String> it=m.keys();while(it.hasNext()){String k=it.next();if(isCustom(k))keys.add(k);}}}
 static List<String> keys(Collection<JSONObject> data,Collection<String> extra){LinkedHashSet<String> keys=new LinkedHashSet<>(Arrays.asList(KEYS));TreeSet<String> custom=new TreeSet<>();for(String k:extra)if(isCustom(k))custom.add(k);for(JSONObject o:data)collect(custom,o);keys.addAll(custom);return new ArrayList<>(keys);}
 static boolean hasAny(JSONObject item){if(item==null)return false;for(String k:keys(Collections.singletonList(item),Collections.emptyList()))if(qty(item,k).signum()>0)return true;return false;}
 static boolean incomplete(JSONObject item){if(item==null||item.optBoolean("no_meat"))return false;if(!hasAny(item))return true;JSONObject m=item.optJSONObject("meat_qty");if(m!=null){Iterator<String> it=m.keys();while(it.hasNext())if(m.optString(it.next()).isEmpty())return true;}return false;}
 static String describe(JSONObject item){StringBuilder s=new StringBuilder();for(String k:keys(Collections.singletonList(item),Collections.emptyList())){BigDecimal v=qty(item,k);if(v.signum()>0){if(s.length()>0)s.append("، ");s.append(label(k)).append(": ").append(format(v)).append(" ").append(unit(k));}else if(item!=null&&item.optJSONObject("meat_qty")!=null&&item.optJSONObject("meat_qty").has(k)&&item.optJSONObject("meat_qty").optString(k).isEmpty()){if(s.length()>0)s.append("، ");s.append(label(k)).append(": غير محدد");}}return s.length()==0?(item!=null&&item.optBoolean("no_meat")?"بدون لحوم":"غير محدد"):s.toString();}
 static BigDecimal total(List<JSONObject> data,String k){BigDecimal t=BigDecimal.ZERO;for(JSONObject o:data)if(!o.optBoolean("deleted"))t=t.add(qty(o,k));return t;}
}
