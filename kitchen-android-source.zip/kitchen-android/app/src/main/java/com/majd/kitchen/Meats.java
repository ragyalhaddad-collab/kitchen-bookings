package com.majd.kitchen;
import java.math.BigDecimal;import java.util.List;import org.json.JSONObject;
final class Meats {
 static final String[] KEYS={"oven_chicken","mandi_chicken","meat_kg","turkey_thigh","turkey_drumstick"};
 static final String[] LABELS={"جاج فرن","جاج مندي","لحمة كيلو","فخد حبش","دبوس حبش"};
 static String unit(int i){return i==2?"كيلو":"عدد";}
 static String format(BigDecimal v){return v.stripTrailingZeros().toPlainString();}
 static BigDecimal qty(JSONObject item,int i){if(item==null)return BigDecimal.ZERO;JSONObject m=item.optJSONObject("meat_qty");if(m==null)return BigDecimal.ZERO;try{BigDecimal v=new BigDecimal(m.optString(KEYS[i],"0"));return v.signum()>0?v:BigDecimal.ZERO;}catch(Exception e){return BigDecimal.ZERO;}}
 static boolean hasAny(JSONObject item){for(int i=0;i<KEYS.length;i++)if(qty(item,i).signum()>0)return true;return false;}
 static String describe(JSONObject item){StringBuilder s=new StringBuilder();for(int i=0;i<KEYS.length;i++){BigDecimal v=qty(item,i);if(v.signum()>0){if(s.length()>0)s.append("، ");s.append(LABELS[i]).append(": ").append(format(v)).append(" ").append(unit(i));}}return s.length()==0?"غير محدد":s.toString();}
 static BigDecimal[] totals(List<JSONObject> data){BigDecimal[] total=new BigDecimal[KEYS.length];for(int i=0;i<total.length;i++){total[i]=BigDecimal.ZERO;for(JSONObject o:data)if(!o.optBoolean("deleted"))total[i]=total[i].add(qty(o,i));}return total;}
}
