package com.majd.kitchen;
import java.math.BigDecimal;
import java.util.regex.*;
import java.text.Normalizer;
final class OrderParser {
 static String normalize(String s){StringBuilder b=new StringBuilder();for(char c:Normalizer.normalize(s,Normalizer.Form.NFKC).toCharArray()){int d=Character.digit(c,10);if(d>=0)b.append(d);else b.append(c);}return b.toString().replaceAll("[\\u064B-\\u065F\\u0670ـ]", "").replace('أ','ا').replace('إ','ا').replace('آ','ا').replace('ى','ي').replace('ة','ه').replace('٫','.').replaceAll("\\s+"," ").trim();}
 static final String NUM="([0-9]{1,6}(?:\\.[0-9]{1,3})?)";
 static final String CH="(?:د?جاج(?:ه|ات)?|جوجه|جواجي)";
 static final String FR="(نص|نصف|ربع|كامل(?:ه)?|حبه)";
 static final Pattern TRAY=Pattern.compile("^"+NUM+" (?:صينيه|صنيه|صواني|صنيات) (?:(?:"+FR+") )?(?:"+CH+" )?(فرن|مندي)(?: كامل(?:ه)?)?$");
 static final Pattern TRAY_FULL=Pattern.compile("^"+NUM+" (?:صينيه|صنيه|صواني|صنيات) "+CH+" كامل(?:ه)? (فرن|مندي)$");
 static final Pattern SHORT=Pattern.compile("^"+NUM+" "+FR+" (?:"+CH+" )?(فرن|مندي)$");
 static final Pattern FULL=Pattern.compile("^"+NUM+" (?:حبه )?"+CH+" (فرن|مندي)(?: كامل(?:ه)?)?$");
 static final Pattern KG=Pattern.compile("^"+NUM+" (?:كيلو(?:غرام|جرام)?|كغم|كجم|كغ) (?:لحمه?|لحم)$");
 static final Pattern KG2=Pattern.compile("^لحمه? "+NUM+" (?:كيلو(?:غرام|جرام)?|كغم|كجم|كغ)$");
 static final Pattern TH=Pattern.compile("^"+NUM+" (?:فخ[دذ](?:ه|ات)?|فخا[دذ]|افخا[دذ]) حبش$");
 static final Pattern DR=Pattern.compile("^"+NUM+" (?:دبوس|دبابيس|دبوسات) حبش$");
 static boolean valid(BigDecimal n,int i){return n.signum()>=0&&n.compareTo(new BigDecimal("999999"))<=0&&n.stripTrailingZeros().scale()<=(i<=2?3:0)&&(i>=2||n.remainder(new BigDecimal("0.25")).signum()==0);}
 static BigDecimal[] parse(String input){String s=normalize(input.replace('\n','،'));if(s.isEmpty()||s.length()>500)return null;String[] parts=s.split("\\s*(?:[+،,;؛\\n]|\\s+و\\s*(?=[0-9]))\\s*",-1);BigDecimal[] result=new BigDecimal[5];java.util.Arrays.fill(result,BigDecimal.ZERO);
 for(String part:parts){part=part.trim();Matcher m=TRAY.matcher(part);int kind=-1;BigDecimal v=null;if(m.matches()){if(m.group(2)==null)return null;kind=m.group(3).equals("فرن")?0:1;v=fraction(m.group(1),m.group(2));}else if((m=TRAY_FULL.matcher(part)).matches()){kind=m.group(2).equals("فرن")?0:1;v=fraction(m.group(1),"كامل");}else if((m=SHORT.matcher(part)).matches()){kind=m.group(3).equals("فرن")?0:1;v=fraction(m.group(1),m.group(2));}else if((m=FULL.matcher(part)).matches()){kind=m.group(2).equals("فرن")?0:1;v=new BigDecimal(m.group(1));}else if((m=KG.matcher(part)).matches()||(m=KG2.matcher(part)).matches()){kind=2;v=new BigDecimal(m.group(1));}else if((m=TH.matcher(part)).matches()){kind=3;v=new BigDecimal(m.group(1));}else if((m=DR.matcher(part)).matches()){kind=4;v=new BigDecimal(m.group(1));}else return null;
 if(v.signum()<=0||!valid(v,kind))return null;result[kind]=result[kind].add(v);if(!valid(result[kind],kind))return null;}return result;}
 static BigDecimal fraction(String num,String part){BigDecimal n=new BigDecimal(num);if(n.stripTrailingZeros().scale()>0)return BigDecimal.ZERO;return n.multiply(part.equals("ربع")?new BigDecimal("0.25"):part.equals("نص")||part.equals("نصف")?new BigDecimal("0.5"):BigDecimal.ONE);}
}
