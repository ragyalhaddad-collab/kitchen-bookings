package com.majd.kitchen;
import android.content.*;
public class SoldSmsResult extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if("com.majd.kitchen.SOLD_SMS_RESULT".equals(i.getAction()))SoldOut.result(c,i,getResultCode());}
}
