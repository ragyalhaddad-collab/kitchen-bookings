package com.majd.kitchen;
import android.app.Activity;import android.content.*;
public class SoldSmsResult extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(!"com.majd.kitchen.SOLD_SMS_RESULT".equals(i.getAction()))return;SoldOut.log(c,i.getStringExtra("number")+" — الجزء "+i.getIntExtra("part",0)+"/"+i.getIntExtra("parts",0)+(getResultCode()==Activity.RESULT_OK?" أُرسل":" فشل الإرسال ("+getResultCode()+")"));}
}
