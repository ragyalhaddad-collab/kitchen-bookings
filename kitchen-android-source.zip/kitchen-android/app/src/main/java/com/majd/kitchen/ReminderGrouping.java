package com.majd.kitchen;
/** Scheduling helpers: original due time is immutable; snooze only changes eligibility. */
final class ReminderGrouping {
 static long effective(long due,long snooze){return snooze>0?snooze:due;}
 static long bucket(long time){return time/60000L;}
 static boolean sameTime(long a,long b){return bucket(a)==bucket(b);}
 static long wake(long now,long nextDue,long gap){return Math.max(Math.max(now+200,nextDue),gap);}
}
