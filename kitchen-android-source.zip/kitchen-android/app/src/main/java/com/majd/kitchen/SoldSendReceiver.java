package com.majd.kitchen;
import android.content.*;
import android.os.*;
public class SoldSendReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  if(!"com.majd.kitchen.SOLD_SEND".equals(i.getAction()))return;
  final String n=i.getStringExtra("number");final int sub=i.getIntExtra("sub",-1);final Context app=c.getApplicationContext();final PendingResult pending=goAsync();
  new Handler(Looper.getMainLooper()).postDelayed(()->{try{SoldOut.send(app,n,sub);}finally{pending.finish();}},2500);
 }
}
