package com.majd.kitchen;
import org.json.*;import java.math.*;
final class OrderLines {
 static JSONObject line(String desc,String count,String price)throws Exception{BigDecimal q=new BigDecimal(count).stripTrailingZeros(),p=new BigDecimal(price).stripTrailingZeros();if(q.signum()<=0||q.scale()>3||q.compareTo(new BigDecimal("999999"))>0||p.signum()<0||p.scale()>2||p.compareTo(new BigDecimal("999999"))>0)throw new IllegalArgumentException("تحقق من عدد الوحدات وسعر الوحدة");return new JSONObject().put("description",desc).put("quantity",q.toPlainString()).put("unit_price",p.toPlainString());}
 static BigDecimal subtotal(JSONObject x){return new BigDecimal(x.optString("quantity")).multiply(new BigDecimal(x.optString("unit_price"))).setScale(2,RoundingMode.HALF_UP);}
 static BigDecimal total(JSONArray a){BigDecimal sum=BigDecimal.ZERO;for(int i=0;i<a.length();i++)sum=sum.add(subtotal(a.optJSONObject(i)));return sum.setScale(2);}
 static String summary(JSONArray a){StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(i>0)s.append("\n");s.append(x.optString("quantity")).append(" × ").append(x.optString("description")).append(" | ").append(x.optString("unit_price")).append(" ₪ = ").append(subtotal(x).toPlainString()).append(" ₪");}return s.toString();}
}
