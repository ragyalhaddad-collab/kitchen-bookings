package com.majd.kitchen;
import org.json.*;import java.math.*;
final class OrderLines {
 static JSONObject line(String desc,String count,String price)throws Exception{String q=OrderAmounts.number(count,true),p=OrderAmounts.number(price,false);return new JSONObject().put("description",OrderAmounts.description(desc,q)).put("quantity",q).put("unit_price",p);}
 static BigDecimal subtotal(JSONObject x){return OrderAmounts.subtotal(x.optString("quantity"),x.optString("unit_price"));}
 // Unknown total is represented as blank in the existing booking price field.
 static String total(JSONArray a){BigDecimal sum=BigDecimal.ZERO;for(int i=0;i<a.length();i++){BigDecimal v=subtotal(a.optJSONObject(i));if(v==null)return "";sum=sum.add(v);}return sum.setScale(2).toPlainString();}
 static String summary(JSONArray a){StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(i>0)s.append("\n");String q=x.optString("quantity"),p=x.optString("unit_price");BigDecimal v=subtotal(x);if(!q.isEmpty())s.append(q).append(" × ");s.append(x.optString("description"));if(q.isEmpty())s.append(" | العدد غير محدد");s.append(p.isEmpty()?" | السعر غير محدد":" | "+p+" ₪");if(v!=null)s.append(" = ").append(v.toPlainString()).append(" ₪");}return s.toString();}
}
