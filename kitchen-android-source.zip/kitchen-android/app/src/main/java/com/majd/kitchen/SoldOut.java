package com.majd.kitchen;

import android.Manifest;
import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.telephony.*;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

/** Device-local opt-in. A cloud status never turns on SMS on another phone. */
final class SoldOut {
 static final String DEFAULT="نعتذر لنفاد الكمية اليوم، ونرجو الحجز قبل يوم أو في وقت مبكر. للاستفسار يرجى إرسال رسالة. شكرًا لتفهمكم. إدارة مطبخ المجد.";
 static String[] perms(){return Build.VERSION.SDK_INT>=29?new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CONTACTS,Manifest.permission.SEND_SMS}:new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG,Manifest.permission.SEND_SMS};}
 static boolean screening(Context c){if(Build.VERSION.SDK_INT<29)return false;try{RoleManager r=c.getSystemService(RoleManager.class);return r!=null&&r.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)&&r.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);}catch(Exception e){return false;}}
 static boolean modern(){return Build.VERSION.SDK_INT>=29;}
 static SharedPreferences p(Context c){return c.getSharedPreferences("majd_sold_out",0);}
 static boolean granted(Context c,String permission){return c.checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED;}
 static boolean ready(Context c){for(String permission:perms())if(!granted(c,permission))return false;return true;}
 static boolean active(Context c){return p(c).getBoolean("configured683",false)&&p(c).getBoolean("enabled",false)&&(!modern()||screening(c))&&p(c).getLong("until",0)>System.currentTimeMillis()&&ready(c)&&sendingSub(c)>=0;}
 static String day(){return new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
 static long midnight(){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
 static String message(Context c){return p(c).getString("message",DEFAULT);}
 static String id(Context c){SharedPreferences p=p(c);String x=p.getString("device","");if(x.isEmpty()){x=UUID.randomUUID().toString();p.edit().putString("device",x).commit();}return x;}
 static String status(Context c){String s=active(c)?(modern()?"رفض المكالمات و SMS مفعّلان حتى منتصف الليل":"SMS مفعّل حتى منتصف الليل (دون رفض)"):"الرد النصي متوقف على هذا الجهاز";if(p(c).getBoolean("enabled",false)&&!ready(c))s="صلاحيات الرد النصي غير مكتملة";if(modern()&&!screening(c))s="الرد متوقف — يلزم السماح بفرز المكالمات";if(active(c))s+=" • الإرسال: "+sendingLabel(c);String remote=p(c).getString("remote_names","");if(!remote.isEmpty()&&p(c).getLong("remote_until",0)>System.currentTimeMillis())s+=" • آخر حالة مستلمة: "+remote;if(Sync.enabled(c)&&p(c).getLong("cloud_at",0)<System.currentTimeMillis()-120000)s+=" • حالة الأجهزة الأخرى غير مؤكدة";return s;}
 static void changed(MainActivity a){a.refreshSold();if(Sync.enabled(a))a.sync(false);}
 static List<SubscriptionInfo> sims(Context c){try{List<SubscriptionInfo> l=c.getSystemService(SubscriptionManager.class).getActiveSubscriptionInfoList();if(l!=null){ArrayList<SubscriptionInfo> result=new ArrayList<>(l);result.sort(Comparator.comparingInt(SubscriptionInfo::getSimSlotIndex));return result;}}catch(Exception ignored){}return Collections.emptyList();}
 static void open(MainActivity a){
 if(p(a).getBoolean("configured683",false)&&p(a).getBoolean("enabled",false)&&p(a).getLong("until",0)>System.currentTimeMillis()){p(a).edit().putBoolean("enabled",false).commit();changed(a);a.toast("تم إيقاف الرد النصي");return;}
 if(!granted(a,Manifest.permission.READ_PHONE_STATE)){a.requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},69);a.toast("اسمح بالصلاحية ثم اضغط التفعيل مجدداً");return;}
 if(modern()&&!screening(a)){try{RoleManager rm=a.getSystemService(RoleManager.class);if(rm!=null&&rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)){a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),72);a.toast("اختر حجوزات المجد ثم اضغط التفعيل مجدداً");}else a.toast("فرز المكالمات غير متاح على هذا الجهاز");}catch(Exception e){a.toast("تعذر طلب صلاحية فرز المكالمات");}return;}
 if(!ready(a)){a.requestPermissions(perms(),70);a.toast("اسمح بالصلاحيات ثم اضغط التفعيل مجدداً");return;}
 List<SubscriptionInfo> sims=sims(a);if(sims.isEmpty()){a.toast("لا توجد شرائح متاحة أو لم يسمح النظام بقراءتها");return;}
 LinearLayout l=a.column();l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);l.setPadding(a.dp(16),a.dp(8),a.dp(16),a.dp(8));
 a.add(l,a.text("الرد برسالة SMS فقط",18,true));
 a.add(l,a.text("حدد شريحة إرسال الرسائل فقط",16,true));
 a.add(l,a.text("يُرفض الاتصال الوارد على أي شريحة، وتُرسل الرسالة حصراً من الشريحة التي تختارها هنا.",14,false));
 RadioGroup sending=new RadioGroup(a);sending.setOrientation(RadioGroup.VERTICAL);
 int saved=p(a).getInt("send_sub",p(a).getInt("fallback_sub",-1));
 for(int k=0;k<sims.size();k++){SubscriptionInfo sim=sims.get(k);RadioButton b=new RadioButton(a);b.setId(k+1);b.setText("SIM "+(sim.getSimSlotIndex()+1)+" — "+sim.getDisplayName());sending.addView(b);if(sim.getSubscriptionId()==saved)sending.check(k+1);}if(sims.size()==1)sending.check(1);a.add(l,sending);
 CheckBox except=new CheckBox(a);except.setText("استثناء أصحاب حجوزات اليوم");except.setChecked(p(a).getBoolean("except",false));a.add(l,except);
 a.add(l,a.text("نص الرسالة:",15,true));a.add(l,a.text(message(a),14,false));
 a.add(l,a.text("إرسال مرة واحدة ناجحة لكل رقم يومياً. إذا فشلت جميع الأجزاء يسمح بمحاولة جديدة عند الاتصال التالي. ينتهي التفعيل عند منتصف الليل. على Android 10 فأحدث: يرفض الاتصال على أي شريحة ويرسل SMS من شريحة الإرسال المحددة فقط. إذا أصبحت الشريحة المحددة غير متاحة يتوقف الرد، ولا يستخدم الشريحة الأخرى. الأرقام المخفية قد لا تصل إلى خدمة الفرز. قد تُحتسب الرسالة عدة أجزاء حسب الشركة. فعّل على جوال المطبخ فقط.",13,false));
 ScrollView sc=new ScrollView(a);sc.addView(l);AlertDialog dialog=new AlertDialog.Builder(a).setTitle("تفعيل خاصية نفاد الكمية").setView(sc).setNegativeButton("إلغاء",null).setPositiveButton("تأكيد التفعيل",null).create();
 dialog.setOnShowListener(v->dialog.getButton(-1).setOnClickListener(w->{int k=sending.getCheckedRadioButtonId()-1;if(k<0||k>=sims.size()){a.toast("حدد شريحة إرسال الرسائل");return;}if(!ready(a)||(modern()&&!screening(a))){a.toast("صلاحيات الرد النصي غير مكتملة");return;}int sub=sims.get(k).getSubscriptionId();boolean available=false;for(SubscriptionInfo si:sims(a))if(si.getSubscriptionId()==sub)available=true;if(!available){a.toast("شريحة الإرسال غير متاحة");return;}if(!p(a).edit().putBoolean("configured683",true).putInt("send_sub",sub).remove("fallback_sub").remove("subs").putInt("method",0).putBoolean("except",except.isChecked()).putBoolean("enabled",true).putBoolean("voice_pending",false).putLong("until",midnight()).commit()){a.toast("تعذر حفظ الإعدادات");return;}dialog.dismiss();changed(a);a.toast("تم تفعيل الرد النصي من الشريحة المحددة");}));dialog.show();
 }
 static File audio(Context c){return new File(c.getFilesDir(),"majd_sold_out.mp3");}
 static void preview(MainActivity a){if(!audio(a).exists()){a.toast("اختر ملف التسجيل أولاً");return;}try{MediaPlayer player=new MediaPlayer();player.setDataSource(audio(a).getAbsolutePath());player.prepare();AlertDialog d=new AlertDialog.Builder(a).setTitle("استماع للتسجيل الصوتي").setMessage("معاينة محلية فقط؛ لا تُشغّل التسجيل داخل مكالمة.").setPositiveButton("إيقاف",null).create();d.setOnDismissListener(v->{try{player.release();}catch(Exception ignored){}});player.setOnCompletionListener(v->d.dismiss());d.show();player.start();}catch(Exception e){a.toast("تعذر تشغيل الملف");}}
 static void chooseAudio(MainActivity a){try{a.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*"),68);}catch(Exception e){a.toast("لا يوجد مدير ملفات");}}
 static void importAudio(MainActivity a,int result,Intent data){if(result!=Activity.RESULT_OK||data==null||data.getData()==null)return;Uri u=data.getData();File tmp=new File(a.getFilesDir(),"majd_voice.tmp");try(InputStream in=a.getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IOException();byte[] b=new byte[8192];long count=0;int n;while((n=in.read(b))!=-1){count+=n;if(count>10*1024*1024)throw new IOException();out.write(b,0,n);}if(count==0)throw new IOException();}catch(Exception e){tmp.delete();a.toast("تعذر حفظ التسجيل (الحد 10 MB)");return;}try{MediaPlayer m=new MediaPlayer();try{m.setDataSource(tmp.getAbsolutePath());m.prepare();}finally{m.release();}if(!tmp.renameTo(audio(a)))throw new IOException();a.toast("تم حفظ التسجيل محلياً");}catch(Exception e){tmp.delete();a.toast("الملف غير قابل للتشغيل");}}
 static void voiceGuide(MainActivity a){p(a).edit().putBoolean("voice_pending",true).apply();a.refreshSold();new AlertDialog.Builder(a).setTitle("الرد الصوتي — يحتاج إعداد شركة الاتصالات").setMessage("أندرويد لا يتيح حقن التسجيل في المكالمات العادية. يجب تسجيل التحية في البريد الصوتي وتفعيل تحويل المكالمات لكل شريحة من إعدادات الهاتف أو الشركة. إيقاف SMS هنا لا يلغي تحويل المكالمات. لم يتم تفعيل الرد الصوتي تلقائياً.").setNeutralButton("اختيار التسجيل",(d,w)->chooseAudio(a)).setPositiveButton("استماع",(d,w)->preview(a)).setNegativeButton("إغلاق",null).show();}
 static void settings(MainActivity a){String[] labels={"تعديل نص SMS","سجل الردود النصية","اختبار إرسال من الشريحة المختارة"};new AlertDialog.Builder(a).setTitle("إعدادات نفاد الكمية").setItems(labels,(d,w)->{if(w==0){EditText e=a.field("رسالة الاعتذار");e.setText(message(a));new AlertDialog.Builder(a).setTitle("نص الرسالة").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(x,y)->{String m=e.getText().toString().trim();if(m.isEmpty()||m.length()>500){a.toast("أدخل رسالة من 1 إلى 500 حرف");return;}p(a).edit().putString("message",m).apply();}).show();}else if(w==2){testDialog(a);}else new AlertDialog.Builder(a).setTitle("سجل الردود على هذا الجهاز").setMessage(p(a).getString("log","لا توجد عمليات بعد")).setPositiveButton("إغلاق",null).show();}).show();}
 static synchronized void log(Context c,String s){String prior=p(c).getString("log","");String time=new java.text.SimpleDateFormat("dd/MM HH:mm:ss",Locale.US).format(new Date());String value=time+" • "+s+"\n"+prior;if(value.length()>16000)value=value.substring(0,16000);p(c).edit().putString("log",value).commit();}
 static String canonical(String raw){String n=DisplayFormat.digits(raw).replaceAll("[^0-9+]","");if(n.startsWith("00"))n="+"+n.substring(2);if(n.matches("\\+?(970|972)5[0-9]{8}"))n="0"+n.substring(n.length()-9);return n;}
 static boolean booked(Context c,String n){if(!p(c).getBoolean("except",false))return false;JSONArray a=Bookings.load(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&!o.optBoolean("deleted")&&day().equals(o.optString("date"))&&n.equals(canonical(o.optString("phone"))))return true;}return false;}
 // Use only the explicitly configured SMS subscription, never infer from incoming calls.
 static int sendingSub(Context c){int selected=p(c).getInt("send_sub",-1);if(selected<0)return -1;for(SubscriptionInfo si:sims(c))if(si.getSubscriptionId()==selected)return selected;return -1;}
 static String sendingLabel(Context c){int sub=sendingSub(c);for(SubscriptionInfo si:sims(c))if(si.getSubscriptionId()==sub)return "SIM "+(si.getSimSlotIndex()+1)+" — "+si.getDisplayName();return "غير متاحة";}
 static boolean validNumber(String n){return n!=null&&n.matches("\\+?[0-9]{7,15}");}
 static synchronized void ring(Context c,Intent i){if(modern()||!active(c))return;String raw=i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);if(raw==null||raw.isEmpty())return;String n=canonical(raw);if(!validNumber(n)||booked(c,n))return;int sub=sendingSub(c);if(sub<0){log(c,n+" — لم ترسل: شريحة الإرسال غير متاحة");return;}send(c,n,sub);}
 static void testDialog(MainActivity a){
  if(!active(a)){a.toast("فعّل نفاد الكمية واختر شريحة الإرسال أولاً");return;}
  EditText e=a.field("رقم جوال الاختبار الآخر");e.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
  new AlertDialog.Builder(a).setTitle("إرسال SMS تجريبية من "+sendingLabel(a)).setMessage("سترسل رسالة فعلية إلى الرقم المدخل، وقد تُخصم تكلفة الرسالة من الشريحة. لا تحتاج إلى اتصال هاتفي.").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("إرسال",(d,w)->{String n=canonical(e.getText().toString());if(!validNumber(n)){a.toast("رقم غير صالح");return;}send(a,n,sendingSub(a),true);a.toast("راجع سجل الردود لمعرفة نتيجة الإرسال");}).show();
 }
 static void queue(Context c,String n,int sub){
  log(c,n+" — جدولة SMS بعد رفض الاتصال • "+sendingLabel(c));
  try{c.sendBroadcast(new Intent(c,SoldSendReceiver.class).setAction("com.majd.kitchen.SOLD_SEND").putExtra("number",n).putExtra("sub",sub));}
  catch(Exception e){log(c,n+" — تعذرت جدولة الإرسال: "+e.getClass().getSimpleName());}
 }
 static void send(Context c,String n,int sub){send(c,n,sub,false);}
 static String ledgerKey(String date,String n){return "sms684:"+date+":"+n;}
 static synchronized void send(Context c,String n,int sub,boolean test){
  if(!validNumber(n))return;
  if(!active(c)){log(c,n+" — لم ترسل: الرد غير مفعّل أو الصلاحيات/الشريحة غير متاحة");return;}
  if(sub<0||sub!=sendingSub(c)){log(c,n+" — لم ترسل: تغيرت شريحة الإرسال، أعد الاتصال");return;}
  SharedPreferences prefs=p(c);String today=day();String batch=UUID.randomUUID().toString();String key=test?"sms684:test:"+batch:ledgerKey(today,n);
  if(!test){
   for(String k:prefs.getAll().keySet())if(k.startsWith("sms684:")&&!k.startsWith("sms684:"+today+":")&&!k.startsWith("sms684:test:"))prefs.edit().remove(k).apply();
   String old=prefs.getString(key,"");if(!old.isEmpty()){String state=SmsBatch.state(old);if(!"failed".equals(state)){log(c,n+" — لم تكرر SMS: "+("sent".equals(state)?"سبق نجاح الإرسال اليوم":"pending".equals(state)?"بانتظار نتيجة محاولة سابقة":"نجح بعض الأجزاء فقط؛ لا تكرر تلقائياً"));return;}}
  }
  boolean recorded=false;
  try{
   SmsManager sms=Build.VERSION.SDK_INT>=31?c.getSystemService(SmsManager.class).createForSubscriptionId(sub):SmsManager.getSmsManagerForSubscriptionId(sub);
   String body=test?"تجربة SMS من مطبخ المجد":message(c);
   ArrayList<String> parts=sms.divideMessage(body);if(parts.isEmpty())throw new IllegalArgumentException("empty SMS");
   String value=SmsBatch.start(batch,parts.size());
   if(!prefs.edit().putString(key,value).commit()){log(c,n+" — تعذر حفظ حالة الإرسال");return;}recorded=true;
   ArrayList<PendingIntent> callbacks=new ArrayList<>();
   for(int j=0;j<parts.size();j++){Intent result=new Intent(c,SoldSmsResult.class).setAction("com.majd.kitchen.SOLD_SMS_RESULT").setData(Uri.parse("majd-sms://result/"+batch+"/"+j)).putExtra("number",n).putExtra("part",j+1).putExtra("parts",parts.size()).putExtra("key",key).putExtra("batch",batch);callbacks.add(PendingIntent.getBroadcast(c,0,result,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_ONE_SHOT));}
   log(c,n+" — طلب "+(test?"اختبار ":"")+"SMS ("+parts.size()+" جزء، "+sendingLabel(c)+"، ID "+sub+")");
   if(parts.size()==1)sms.sendTextMessage(n,null,parts.get(0),callbacks.get(0),null);else sms.sendMultipartTextMessage(n,null,parts,callbacks,null);
  }catch(Exception e){if(recorded)prefs.edit().remove(key).commit();log(c,n+" — تعذر الإرسال: "+e.getClass().getSimpleName()+"؛ يسمح بمحاولة جديدة");}
 }
 static synchronized void result(Context c,Intent i,int code){
  String key=i.getStringExtra("key"),batch=i.getStringExtra("batch"),n=i.getStringExtra("number");int part=i.getIntExtra("part",0);if(key==null||batch==null||n==null){log(c,"نتيجة إرسال قديمة ("+code+")");return;}
  SharedPreferences prefs=p(c);String old=prefs.getString(key,"");String value=SmsBatch.update(old,batch,part,code==Activity.RESULT_OK);if(value.equals(old))return;
  if(!prefs.edit().putString(key,value).commit()){log(c,n+" — تعذر حفظ نتيجة SMS");return;}
  log(c,n+" — الجزء "+part+"/"+i.getIntExtra("parts",0)+(code==Activity.RESULT_OK?" أُرسل":" فشل الإرسال ("+code+")"));
  String state=SmsBatch.state(value);if(!"pending".equals(state)){
   log(c,n+" — "+("sent".equals(state)?"نجح إرسال جميع الأجزاء (ليس تأكيد وصول)":"failed".equals(state)?"فشلت جميع الأجزاء؛ يسمح بالمحاولة عند الاتصال التالي":"نجح بعض الأجزاء فقط؛ لا تكرر تلقائياً"));
   if(key.startsWith("sms684:test:"))prefs.edit().remove(key).apply();
  }
 }
 // Share informational status only. Receiving it can never activate this phone.
 static void cloud(Context c,String base,String key,String token,String owner)throws Exception{JSONObject body=new JSONObject().put("owner",owner).put("device",id(c)).put("label",Bookings.prefs(c).getString("employee_name","جوال المجد")).put("enabled",active(c)).put("until_ms",p(c).getLong("until",0));Sync.request(base,key,token,"/rest/v1/majd_soldout_status?on_conflict=owner,device","POST",body.toString(),"resolution=merge-duplicates,return=minimal");JSONArray rows=new JSONArray(Sync.request(base,key,token,"/rest/v1/majd_soldout_status?select=device,label,enabled,until_ms","GET",null,null));StringBuilder names=new StringBuilder();long until=0;for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);if(r.optString("device").equals(id(c))||!r.optBoolean("enabled")||r.optLong("until_ms")<=System.currentTimeMillis())continue;if(names.length()>0)names.append("، ");names.append(r.optString("label"));until=Math.max(until,r.optLong("until_ms"));}p(c).edit().putString("remote_names",names.toString()).putLong("remote_until",until).putLong("cloud_at",System.currentTimeMillis()).apply();}
}
