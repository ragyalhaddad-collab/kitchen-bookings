package com.majd.kitchen;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallScreeningService;
import android.net.Uri;

/** No access to the audio stream; this service screens incoming calls only. */
public class SoldScreeningService extends CallScreeningService {
 @Override public void onScreenCall(Call.Details details){
  if(Build.VERSION.SDK_INT<29 || details.getCallDirection()!=Call.Details.DIRECTION_INCOMING)return;
  boolean reject=false; int sub=-1; String n=""; String reason="";
  try{
   if(SoldOut.active(this)){
    Uri h=details.getHandle();
    if(h!=null&&"tel".equals(h.getScheme()))n=SoldOut.canonical(h.getSchemeSpecificPart());
    if(!SoldOut.validNumber(n))reason="رقم غير متاح";
    else if(SoldOut.booked(this,n))reason="حجز اليوم — مستثنى";
    else {sub=SoldOut.sendingSub(this);if(sub>=0)reject=true;else reason="شريحة الإرسال المحددة غير متاحة";}
   }
  }catch(Exception e){reject=false;reason="تعذر التحقق من المكالمة";}
  try{respondToCall(details,new CallResponse.Builder().setDisallowCall(reject).setRejectCall(reject).setSkipCallLog(false).setSkipNotification(false).build());}
  catch(Exception e){if(!n.isEmpty())SoldOut.log(this,n+" — تعذر طلب رفض المكالمة");return;}
  if(reject){SoldOut.log(this,n+" — طلب رفض المكالمة"+" • شريحة الإرسال: "+SoldOut.sendingLabel(this));SoldOut.queue(this,n,sub);}
  else if(!reason.isEmpty()&&!n.isEmpty())SoldOut.log(this,n+" — لم تُرفض ولم تُرسل: "+reason);
 }
}
