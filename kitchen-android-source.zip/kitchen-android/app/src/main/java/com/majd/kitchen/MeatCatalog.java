package com.majd.kitchen;
import android.content.Context;import org.json.*;import java.util.*;
final class MeatCatalog {
 static JSONObject load(Context c){try{return new JSONObject(Bookings.prefs(c).getString("meat_catalog_v64","{}"));}catch(Exception e){return new JSONObject();}}
 static List<String> keys(Context c){JSONObject catalog=load(c);ArrayList<String> extra=new ArrayList<>();Iterator<String> it=catalog.keys();while(it.hasNext())extra.add(it.next());ArrayList<JSONObject> data=new ArrayList<>();JSONArray a=Bookings.load(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)data.add(o);}return Meats.keys(data,extra);}
 static void add(Context c,String k,String actor)throws Exception{JSONObject catalog=load(c);if(catalog.has(k))return;catalog.put(k,new JSONObject().put("code",k).put("actor",actor).put("pending",true));if(!Bookings.prefs(c).edit().putString("meat_catalog_v64",catalog.toString()).commit())throw new java.io.IOException("تعذر حفظ الصنف");}
 static void merge(Context c,JSONArray remote)throws Exception{JSONObject catalog=load(c);for(int i=0;i<remote.length();i++){JSONObject row=remote.getJSONObject(i);String k=row.getString("code");if(Meats.isCustom(k))catalog.put(k,row);}if(!Bookings.prefs(c).edit().putString("meat_catalog_v64",catalog.toString()).commit())throw new java.io.IOException("تعذر حفظ الأصناف");}
}
