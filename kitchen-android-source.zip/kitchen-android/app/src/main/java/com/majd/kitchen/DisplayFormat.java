package com.majd.kitchen;
import java.text.SimpleDateFormat;
import java.util.*;
final class DisplayFormat {
 static String digits(String s){if(s==null)return "";StringBuilder b=new StringBuilder();for(char c:s.toCharArray()){int d=Character.digit(c,10);b.append(d>=0?(char)('0'+d):c);}return b.toString();}
 static String date(String s){s=digits(s);if(s.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))return s.substring(8,10)+"/"+s.substring(5,7)+"/"+s.substring(0,4);return s;}
 static String friday(Calendar today){Calendar c=(Calendar)today.clone();int days=(Calendar.FRIDAY-c.get(Calendar.DAY_OF_WEEK)+7)%7;c.add(Calendar.DAY_OF_YEAR,days);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(c.getTimeZone());return f.format(c.getTime());}
}
