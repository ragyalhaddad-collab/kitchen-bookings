package com.majd.kitchen;
/** Pure state machine: never treat an attempted send as confirmed. */
final class SmsBatch {
 static String callKey(String day,String n,String callId){return "sms684:"+day+":call:"+n+":"+callId;}
 static String repeatHistoryKey(String day,String n){return "sms684:"+day+":repeat-history:"+n;}
 static boolean blocked(boolean repeat,String old,String repeatHistory){return repeat?!old.isEmpty():!repeatHistory.isEmpty()||(!old.isEmpty()&&!"failed".equals(state(old)));}
 static String start(String batch,int count){if(count<1)throw new IllegalArgumentException();StringBuilder b=new StringBuilder(batch).append(':');for(int i=0;i<count;i++)b.append('?');return b.toString();}
 static String update(String value,String batch,int part,boolean success){int k=value.indexOf(':');if(k<0||!value.substring(0,k).equals(batch)||part<1||part>value.length()-k-1)return value;int i=k+part;if(value.charAt(i)!='?')return value;return value.substring(0,i)+(success?'S':'F')+value.substring(i+1);}
 static String state(String value){int k=value.indexOf(':');if(k<0)return "pending";String parts=value.substring(k+1);if(parts.isEmpty()||parts.indexOf('?')>=0)return "pending";if(parts.indexOf('F')<0)return "sent";if(parts.indexOf('S')<0)return "failed";return "partial";}
}
