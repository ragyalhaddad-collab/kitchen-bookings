package com.majd.kitchen;
import java.math.*;
import java.util.regex.*;
/** Pure rules shared by the editor and tests. Blank is unknown, not zero. */
final class OrderAmounts {
 static String number(String s,boolean quantity){
  if(s==null||s.trim().isEmpty())return "";
  BigDecimal v=new BigDecimal(s.trim()).stripTrailingZeros();
  if((quantity?v.signum()<=0:v.signum()<0)||v.scale()>(quantity?3:2)||v.compareTo(new BigDecimal("999999"))>0)throw new IllegalArgumentException("تحقق من عدد الوحدات وسعر الوحدة");
  return v.toPlainString();
 }
 static String description(String raw,String quantity){
  String d=raw.trim();
  if(!quantity.isEmpty()){
   Matcher m=Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)\\s*(?:[×xX*]\\s*)?\\s+(.+)$").matcher(d);
   Matcher explicit=Pattern.compile("^([0-9]+(?:\\.[0-9]+)?)\\s*[×xX*]\\s*(.+)$").matcher(d);
   if(explicit.matches())m=explicit;else if(!m.matches())m=null;
   if(m!=null&&new BigDecimal(m.group(1)).compareTo(new BigDecimal(quantity))==0)d=m.group(2).trim();
  }
  if(d.isEmpty()||d.matches("[0-9]+(?:\\.[0-9]+)?"))throw new IllegalArgumentException("أدخل اسم الصنف وليس العدد فقط");
  return d;
 }
 static BigDecimal subtotal(String q,String p){return q.isEmpty()||p.isEmpty()?null:new BigDecimal(q).multiply(new BigDecimal(p)).setScale(2,RoundingMode.HALF_UP);}
}
