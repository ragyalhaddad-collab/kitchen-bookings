package com.majd.kitchen;
import android.app.*; import android.content.*; import android.os.Build; import org.json.*; import java.util.*;
final class Bookings {
 static final String CHANNEL="kitchen_reminders";
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("bookings",0);}
 static JSONArray load(Context c){try{return new JSONArray(prefs(c).getString("items","[]"));}catch(Exception e){return new JSONArray();}}
 static void save(Context c, JSONArray a){prefs(c).edit().putString("items",a.toString()).commit();}
 static int next(Context c){int i=prefs(c).getInt("next",1);prefs(c).edit().putInt("next",i+1).commit();return i;}
 static Calendar date(String s){String[] p=s.split("-");Calendar c=Calendar.getInstance();c.clear();c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),12,0,0);return c;}
 static long reminder(JSONObject o){Calendar c=date(o.optString("date"));c.add(Calendar.DAY_OF_YEAR,-1);c.set(Calendar.HOUR_OF_DAY,17);return c.getTimeInMillis();}
 static PendingIntent pi(Context c,int id){return PendingIntent.getBroadcast(c,id,new Intent(c,ReminderReceiver.class).putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
 static void cancel(Context c,int id){c.getSystemService(AlarmManager.class).cancel(pi(c,id));c.getSystemService(NotificationManager.class).cancel(id);}
 static void schedule(Context c,JSONObject o){if(o.optBoolean("sent"))return;long t=reminder(o);if(t<=System.currentTimeMillis()){if(date(o.optString("date")).getTimeInMillis()+43200000L>System.currentTimeMillis())t=System.currentTimeMillis()+1000;else return;}AlarmManager a=c.getSystemService(AlarmManager.class);PendingIntent p=pi(c,o.optInt("id"));try{if(exact(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);}catch(SecurityException e){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);}}
 static void restore(Context c){JSONArray a=load(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)schedule(c,o);}}
 static void channel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"تذكيرات حجوزات المطبخ",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);c.getSystemService(NotificationManager.class).createNotificationChannel(ch);}}
}
