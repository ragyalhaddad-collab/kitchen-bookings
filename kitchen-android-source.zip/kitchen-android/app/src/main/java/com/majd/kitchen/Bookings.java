package com.majd.kitchen;
import android.app.*; import android.content.*; import android.os.Build; import android.media.*; import android.net.Uri; import org.json.*; import java.util.*;
final class Bookings {
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("bookings",0);}
 static JSONArray load(Context c){try{return new JSONArray(prefs(c).getString("items","[]"));}catch(Exception e){return new JSONArray();}}
 static void save(Context c, JSONArray a){prefs(c).edit().putString("items",a.toString()).commit();}
 static int next(Context c){int i=prefs(c).getInt("next",1);prefs(c).edit().putInt("next",i+1).commit();return i;}
 static Calendar date(String s){String[] p=s.split("-");Calendar c=Calendar.getInstance();c.clear();c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]),12,0,0);return c;}
 static long reminder(JSONObject o){Calendar c=date(o.optString("date"));c.add(Calendar.DAY_OF_YEAR,-1);c.set(Calendar.HOUR_OF_DAY,o.optInt("hour",17));c.set(Calendar.MINUTE,o.optInt("minute",0));return c.getTimeInMillis();}
 static PendingIntent pi(Context c,int id){return PendingIntent.getBroadcast(c,id,new Intent(c,ReminderReceiver.class).putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||c.getSystemService(AlarmManager.class).canScheduleExactAlarms();}
 static void cancel(Context c,int id){c.getSystemService(AlarmManager.class).cancel(pi(c,id));c.getSystemService(NotificationManager.class).cancel(id);}
 static void schedule(Context c,JSONObject o){if(o.optBoolean("sent")||o.optBoolean("deleted"))return;long t=reminder(o);if(t<=System.currentTimeMillis()){Calendar end=date(o.optString("date"));end.add(Calendar.DAY_OF_YEAR,1);end.set(Calendar.HOUR_OF_DAY,0);if(end.getTimeInMillis()>System.currentTimeMillis())t=System.currentTimeMillis()+1000;else return;}AlarmManager a=c.getSystemService(AlarmManager.class);PendingIntent p=pi(c,o.optInt("id"));try{if(exact(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);}catch(SecurityException e){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t,p);}}
 static void restore(Context c){JSONArray a=load(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)schedule(c,o);}}
 static String sound(Context c){return prefs(c).getString("sound",RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION).toString());}
 static String channel(Context c){String s=sound(c);String id="majd_reminder_"+Integer.toHexString(s.hashCode());if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(id,"تذكيرات المجد",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);ch.setSound(s.isEmpty()?null:Uri.parse(s),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());c.getSystemService(NotificationManager.class).createNotificationChannel(ch);}return id;}
 static void migrate(Context c){JSONArray a=load(c);boolean changed=false;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;try{if(!o.has("uid")){o.put("uid",UUID.randomUUID().toString());o.put("revision",UUID.randomUUID().toString());o.put("dirty",true);changed=true;}}catch(Exception ignored){}}if(changed)save(c,a);}
}
