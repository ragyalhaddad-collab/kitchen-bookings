package com.majd.kitchen;
import android.content.*;import android.telephony.TelephonyManager;
public class SoldCallReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(i.getAction())&&TelephonyManager.EXTRA_STATE_RINGING.equals(i.getStringExtra(TelephonyManager.EXTRA_STATE)))SoldOut.ring(c,i);}
}
