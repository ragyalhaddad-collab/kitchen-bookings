# V6.8.5 (versionCode 20)
- Adds saved SMS repeat setting, in activation and More > Sold-out settings. Default remains once per number per day.
- Repeat mode uses a separate batch for each incoming call; Android 10+ screening path identifies calls by creation timestamp and caller number. Tracks partial and successful results separately and retains daily history when changing back to daily mode.
- Keeps existing chosen SMS subscription, rejection, 2.5-second send delay and all booking/sync code. No SQL change.
- Local JVM unit checks and Java syntax parse are not an Android build or physical-device test. Verify on both SIMs with repeat on/off before publishing.
