-- Run in Supabase SQL editor in a new private project.
create table if not exists public.majd_bookings (
 owner uuid not null references auth.users(id) on delete cascade,
 id uuid not null,
 payload jsonb not null check (jsonb_typeof(payload) = 'object'),
 primary key (owner, id)
);
alter table public.majd_bookings enable row level security;
revoke all on table public.majd_bookings from anon;
grant select, insert, update on table public.majd_bookings to authenticated;
create policy "majd_read_own" on public.majd_bookings for select to authenticated using (auth.uid() = owner);
create policy "majd_insert_own" on public.majd_bookings for insert to authenticated with check (auth.uid() = owner);
create policy "majd_update_own" on public.majd_bookings for update to authenticated using (auth.uid() = owner) with check (auth.uid() = owner);
-- Create one dedicated kitchen user in Authentication > Users; use that account on authorized phones only.
-- Disable public signup in Authentication settings. Never use the service_role or secret key in the app.
