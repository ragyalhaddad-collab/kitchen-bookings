-- V6.6: append-only manual Ameen confirmation events; no modification to existing bookings.
begin;
create table if not exists public.majd_ameen_events (
 owner uuid not null references auth.users(id) on delete cascade,
 id uuid not null,
 booking_id uuid not null,
 booking_revision text not null check (char_length(booking_revision) between 1 and 100),
 registered boolean not null,
 actor text not null check (char_length(btrim(actor)) between 1 and 80),
 device_time timestamptz not null,
 recorded_at timestamptz not null default clock_timestamp(),
 snapshot jsonb not null check (jsonb_typeof(snapshot)='object'),
 primary key(owner,id),
 foreign key(owner,booking_id) references public.majd_bookings(owner,id)
);
alter table public.majd_ameen_events enable row level security;
revoke all on public.majd_ameen_events from public,anon,authenticated;
grant select on public.majd_ameen_events to authenticated;
grant insert(owner,id,booking_id,booking_revision,registered,actor,device_time,snapshot) on public.majd_ameen_events to authenticated;
drop policy if exists ameen_read on public.majd_ameen_events;
create policy ameen_read on public.majd_ameen_events for select to authenticated using(auth.uid()=owner);
drop policy if exists ameen_insert on public.majd_ameen_events;
create policy ameen_insert on public.majd_ameen_events for insert to authenticated with check(auth.uid()=owner and snapshot->>'revision'=booking_revision);
create index if not exists majd_ameen_events_owner_date on public.majd_ameen_events(owner,recorded_at,id);
commit;
