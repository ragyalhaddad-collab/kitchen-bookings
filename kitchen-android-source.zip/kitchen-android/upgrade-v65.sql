-- Upgrade the existing database. Run once before deploying V6.5. No booking rows are removed.
begin;
create table if not exists public.majd_devices (
 owner uuid not null references auth.users(id) on delete cascade,
 device_id uuid not null, actor text not null check (char_length(btrim(actor)) between 1 and 80),
 registered_at timestamptz not null default clock_timestamp(),
 primary key(owner,device_id)
);
alter table public.majd_devices add column if not exists registered_at timestamptz not null default clock_timestamp();
create table if not exists public.majd_alerts (
 owner uuid not null references auth.users(id) on delete cascade,
 id uuid not null, booking_id uuid not null, sender_device uuid not null,
 actor text not null check (char_length(btrim(actor)) between 1 and 80),
 note text not null default '' check (char_length(note)<=2000),
 snapshot jsonb not null check(jsonb_typeof(snapshot)='object'),
 recorded_at timestamptz not null default clock_timestamp(),
 primary key(owner,id), foreign key(owner,booking_id) references public.majd_bookings(owner,id),
 foreign key(owner,sender_device) references public.majd_devices(owner,device_id)
);
create table if not exists public.majd_alert_receipts (
 owner uuid not null references auth.users(id) on delete cascade,
 alert_id uuid not null, device_id uuid not null, actor text not null check (char_length(btrim(actor)) between 1 and 80),
 recorded_at timestamptz not null default clock_timestamp(),
 primary key(owner,alert_id,device_id),
 foreign key(owner,alert_id) references public.majd_alerts(owner,id),
 foreign key(owner,device_id) references public.majd_devices(owner,device_id)
);
do $$ declare tbl text; begin
 foreach tbl in array array['majd_devices','majd_alerts','majd_alert_receipts'] loop
 execute format('alter table public.%I enable row level security',tbl);
 execute format('revoke all on public.%I from public,anon,authenticated',tbl);
 execute format('grant select on public.%I to authenticated',tbl);
 execute format('drop policy if exists owner_read on public.%I',tbl);
 execute format('create policy owner_read on public.%I for select to authenticated using (auth.uid()=owner)',tbl);
 execute format('drop policy if exists owner_insert on public.%I',tbl);
 execute format('create policy owner_insert on public.%I for insert to authenticated with check (auth.uid()=owner)',tbl);
 end loop;
end $$;
grant insert(owner,device_id,actor), update(owner,device_id,actor) on public.majd_devices to authenticated;
drop policy if exists owner_update on public.majd_devices;
create policy owner_update on public.majd_devices for update to authenticated using(auth.uid()=owner) with check(auth.uid()=owner);
grant insert(owner,id,booking_id,sender_device,actor,note,snapshot) on public.majd_alerts to authenticated;
grant insert(owner,alert_id,device_id,actor) on public.majd_alert_receipts to authenticated;
create index if not exists majd_alerts_owner_date on public.majd_alerts(owner,recorded_at);
create index if not exists majd_receipts_owner_date on public.majd_alert_receipts(owner,recorded_at);
create index if not exists majd_audit_owner_date on public.majd_audit(owner,recorded_at);
-- Restricted archive; copied records are retained as backup, not permanently deleted.
create schema if not exists majd_private;
revoke all on schema majd_private from public,anon,authenticated;
create table if not exists majd_private.audit_archive (like public.majd_audit including all);
revoke all on majd_private.audit_archive from public,anon,authenticated;
create table if not exists majd_private.alert_archive (like public.majd_alerts including all);
create table if not exists majd_private.receipt_archive (like public.majd_alert_receipts including all);
revoke all on majd_private.alert_archive,majd_private.receipt_archive from public,anon,authenticated;
-- Preserve idempotency for archived revisions; this function checks auth.uid and does not expose archive data.
create or replace function public.majd_apply_booking(p_id uuid,p_payload jsonb) returns void
language plpgsql security definer set search_path = '' as $$
declare v_owner uuid := auth.uid(); v_rev text := p_payload->>'revision';
begin
 if v_owner is null or p_id is null or coalesce(v_rev,'')='' or jsonb_typeof(p_payload) is distinct from 'object' then raise exception 'Invalid operation'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_owner::text||p_id::text,0));
 if exists(select 1 from public.majd_audit where owner=v_owner and booking_id=p_id and revision=v_rev)
 or exists(select 1 from majd_private.audit_archive where owner=v_owner and booking_id=p_id and revision=v_rev) then return; end if;
 insert into public.majd_bookings(owner,id,payload) values(v_owner,p_id,p_payload)
 on conflict(owner,id) do update set payload=excluded.payload;
end $$;
revoke all on function public.majd_apply_booking(uuid,jsonb) from public,anon;
grant execute on function public.majd_apply_booking(uuid,jsonb) to authenticated;
-- Archive maintenance is admin-only. Move rows atomically, only after their full copy exists.
create or replace function majd_private.archive_old_audit() returns bigint
language plpgsql security definer set search_path = '' as $$
declare n bigint; cutoff timestamptz := clock_timestamp()-interval '30 days';
begin
 lock table public.majd_audit in share row exclusive mode;
 insert into majd_private.audit_archive select * from public.majd_audit where recorded_at<cutoff on conflict do nothing;
 delete from public.majd_audit a where a.recorded_at<cutoff and exists(select 1 from majd_private.audit_archive b where b.owner=a.owner and b.booking_id=a.booking_id and b.revision=a.revision and b.after_data=a.after_data and b.before_data is not distinct from a.before_data);
 get diagnostics n=row_count;
 -- Shared reminders and receipts remain on the server; only the application shows the latest 30 days.
 return n;
end $$;
revoke all on function majd_private.archive_old_audit() from public,anon,authenticated;
commit;
-- After checking the backup, an administrator can run separately:
-- select majd_private.archive_old_audit();
-- Optional daily schedule via Supabase Cron: 0 2 * * *, command select majd_private.archive_old_audit();
