-- Run once on the EXISTING Majd Supabase project, before using V4.
-- No booking rows are removed or replaced by this migration.
begin;
revoke delete on public.majd_bookings from public, anon, authenticated;
create table if not exists public.majd_audit (
 owner uuid not null references auth.users(id) on delete cascade,
 booking_id uuid not null,
 revision text not null,
 action text not null,
 actor text not null,
 device_time timestamptz,
 recorded_at timestamptz not null default clock_timestamp(),
 before_data jsonb,
 after_data jsonb not null,
 primary key (owner,booking_id,revision)
);
alter table public.majd_audit enable row level security;
revoke all on public.majd_audit from public, anon, authenticated;
grant select on public.majd_audit to authenticated;
drop policy if exists majd_audit_read on public.majd_audit;
create policy majd_audit_read on public.majd_audit for select to authenticated using (auth.uid()=owner);
create or replace function public.majd_capture_audit() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  previous jsonb;
  operation text;
  employee text;
  client_time timestamptz;
  rev text;
begin
  if TG_OP='UPDATE' then
    previous := OLD.payload;
    if previous=NEW.payload then return NEW; end if;
  end if;
  if TG_OP='INSERT' then operation := 'create';
  elsif coalesce(NEW.payload->>'deleted','false')='true' and coalesce(previous->>'deleted','false')<>'true' then operation := 'delete';
  elsif coalesce(NEW.payload->>'deleted','false')<>'true' and coalesce(previous->>'deleted','false')='true' then operation := 'restore';
  else operation := 'edit'; end if;
  employee := coalesce(nullif(btrim(NEW.payload->>'last_actor'),''),case when TG_OP='INSERT' then nullif(btrim(NEW.payload->>'created_by'),'') end,'غير مسجل');
  begin client_time := (NEW.payload->>'last_at')::timestamptz; exception when others then client_time := null; end;
  rev := coalesce(nullif(NEW.payload->>'revision',''),gen_random_uuid()::text);
  insert into public.majd_audit(owner,booking_id,revision,action,actor,device_time,before_data,after_data)
    values(NEW.owner,NEW.id,rev,operation,employee,client_time,previous,NEW.payload)
    on conflict (owner,booking_id,revision) do nothing;
  return NEW;
end; $$;
revoke all on function public.majd_capture_audit() from public, anon, authenticated;
drop trigger if exists majd_audit_capture on public.majd_bookings;
create trigger majd_audit_capture after insert or update on public.majd_bookings for each row execute function public.majd_capture_audit();
-- Atomic idempotent replay: one queued operation per revision, with server-side audit.
create or replace function public.majd_apply_booking(p_id uuid,p_payload jsonb) returns void
language plpgsql security invoker set search_path = '' as $$
declare v_owner uuid := auth.uid(); v_rev text := p_payload->>'revision';
begin
  if v_owner is null or coalesce(v_rev,'')='' or jsonb_typeof(p_payload)<>'object' then raise exception 'Invalid operation'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_owner::text||p_id::text,0));
  if exists(select 1 from public.majd_audit where owner=v_owner and booking_id=p_id and revision=v_rev) then return; end if;
  insert into public.majd_bookings(owner,id,payload) values(v_owner,p_id,p_payload)
  on conflict(owner,id) do update set payload=excluded.payload;
end; $$;
revoke all on function public.majd_apply_booking(uuid,jsonb) from public,anon;
grant execute on function public.majd_apply_booking(uuid,jsonb) to authenticated;
commit;
