-- Optional, run only from the SQL Editor as administrator after upgrade-v65.sql.
-- Supabase Cron must be available. This retains a restricted full copy in the same database.
create extension if not exists pg_cron;
select cron.schedule('majd-audit-retention-v65','0 2 * * *','select majd_private.archive_old_audit();');
