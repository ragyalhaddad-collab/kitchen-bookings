-- V6.8: optional informational status for automatic SMS on authorized devices.
-- No changes to bookings, audit, Ameen confirmation, credentials or reminders.
begin;
create table if not exists public.majd_soldout_status (
 owner uuid not null references auth.users(id) on delete cascade,
 device uuid not null,
 label text not null check (char_length(label)<=100),
 enabled boolean not null default false,
 until_ms bigint not null default 0 check(until_ms>=0),
 primary key(owner,device)
);
alter table public.majd_soldout_status enable row level security;
revoke all on public.majd_soldout_status from public,anon,authenticated;
grant select,insert,update on public.majd_soldout_status to authenticated;
drop policy if exists soldout_read on public.majd_soldout_status;
create policy soldout_read on public.majd_soldout_status for select to authenticated using(auth.uid()=owner);
drop policy if exists soldout_insert on public.majd_soldout_status;
create policy soldout_insert on public.majd_soldout_status for insert to authenticated with check(auth.uid()=owner);
drop policy if exists soldout_update on public.majd_soldout_status;
create policy soldout_update on public.majd_soldout_status for update to authenticated using(auth.uid()=owner) with check(auth.uid()=owner);
commit;
