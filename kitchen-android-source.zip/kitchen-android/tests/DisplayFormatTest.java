package com.majd.kitchen;
import java.util.*;
public class DisplayFormatTest {
 static void check(String got,String want){if(!got.equals(want))throw new AssertionError(got+" != "+want);}
 public static void main(String[] args){Locale.setDefault(Locale.forLanguageTag("ar"));Calendar c=new GregorianCalendar(TimeZone.getTimeZone("Asia/Gaza"));c.clear();c.set(2026,Calendar.NOVEMBER,21,12,0,0);for(int i=0;i<7;i++){check(DisplayFormat.friday(c),"2026-11-27");c.add(Calendar.DATE,1);}check(DisplayFormat.friday(c),"2026-12-04");c.set(2026,Calendar.DECEMBER,31,12,0,0);check(DisplayFormat.friday(c),"2027-01-01");check(DisplayFormat.digits("١٢٣٤٥٦٧٨٩٠ ۱۲۳ 45.5"),"1234567890 123 45.5");check(DisplayFormat.date("٢٠٢٦-١١-٢٧"),"27/11/2026");System.out.println("11 Friday/date/digit checks passed");}
}
