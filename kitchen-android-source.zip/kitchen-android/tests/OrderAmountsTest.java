package com.majd.kitchen;
import java.math.*;
public class OrderAmountsTest {
 static int count=0;static void eq(Object a,Object b){count++;if(!java.util.Objects.equals(a,b))throw new AssertionError(a+" != "+b);} static void invalid(Runnable r){count++;try{r.run();}catch(IllegalArgumentException e){return;}throw new AssertionError("expected invalid input");}
 public static void main(String[] args){
 eq(OrderAmounts.number("",true),"");eq(OrderAmounts.number("",false),"");eq(OrderAmounts.number("45.000",true),"45");eq(OrderAmounts.number("1",false),"1");eq(OrderAmounts.number("0",false),"0");eq(OrderAmounts.number("0.125",true),"0.125");invalid(()->OrderAmounts.number("0",true));invalid(()->OrderAmounts.number("-1",false));invalid(()->OrderAmounts.number("1.123",false));invalid(()->OrderAmounts.number("0.0001",true));invalid(()->OrderAmounts.number("1000000",true));
 eq(OrderAmounts.description("45 × صنية رز","45"),"صنية رز");eq(OrderAmounts.description("45 صنية رز","45"),"صنية رز");eq(OrderAmounts.description("صنية رز","45"),"صنية رز");eq(OrderAmounts.description("45 صنية رز",""),"45 صنية رز");eq(OrderAmounts.description("20 × صنية رز","45"),"20 × صنية رز");invalid(()->OrderAmounts.description("45","45"));invalid(()->OrderAmounts.description("45 × 45","45"));
 eq(OrderAmounts.subtotal("45","1"),new BigDecimal("45.00"));eq(OrderAmounts.subtotal("","1"),null);eq(OrderAmounts.subtotal("45",""),null);eq(OrderAmounts.subtotal("",""),null);eq(OrderAmounts.subtotal("45","0"),new BigDecimal("0.00"));eq(OrderAmounts.subtotal("0.125","1"),new BigDecimal("0.13"));System.out.println(count+" order amount checks passed");
 }
}
