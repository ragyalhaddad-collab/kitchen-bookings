package com.majd.kitchen;
public class SmsBatchTest {
 static int checks=0;
 static void eq(String expected,String actual){checks++;if(!expected.equals(actual))throw new AssertionError(expected+" != "+actual);}
 public static void main(String[] args){
  String a=SmsBatch.start("a",2);eq("pending",SmsBatch.state(a));
  String b=SmsBatch.update(a,"a",2,true);eq("pending",SmsBatch.state(b));eq(b,SmsBatch.update(b,"a",2,false));eq(b,SmsBatch.update(b,"old",1,true));eq(b,SmsBatch.update(b,"a",3,true));
  eq("sent",SmsBatch.state(SmsBatch.update(b,"a",1,true)));eq("partial",SmsBatch.state(SmsBatch.update(b,"a",1,false)));
  String f=SmsBatch.update(a,"a",1,false);eq("pending",SmsBatch.state(f));eq("failed",SmsBatch.state(SmsBatch.update(f,"a",2,false)));eq("partial",SmsBatch.state(SmsBatch.update(f,"a",2,true)));
  String one=SmsBatch.start("b",1);eq("sent",SmsBatch.state(SmsBatch.update(one,"b",1,true)));eq("failed",SmsBatch.state(SmsBatch.update(one,"b",1,false)));eq("",SmsBatch.update("","b",1,true));
  eq("false",Boolean.toString(SmsBatch.blocked(false,"","")));
  eq("true",Boolean.toString(SmsBatch.blocked(false,a,"")));
  eq("false",Boolean.toString(SmsBatch.blocked(false,SmsBatch.update(f,"a",2,false),"")));
  eq("true",Boolean.toString(SmsBatch.blocked(false,"","sent")));
  eq("false",Boolean.toString(SmsBatch.blocked(true,"","sent")));
  eq("true",Boolean.toString(SmsBatch.blocked(true,a,"")));
  eq("true",Boolean.toString(SmsBatch.blocked(true,SmsBatch.update(f,"a",2,false),"")));
  eq("false",Boolean.toString(SmsBatch.callKey("2026-11-28","0591234567","1").equals(SmsBatch.callKey("2026-11-28","0591234567","2"))));
  eq("true",Boolean.toString(SmsBatch.callKey("2026-11-28","0591234567","1").equals(SmsBatch.callKey("2026-11-28","0591234567","1"))));
  System.out.println(checks+" SMS batch checks passed");
 }
}
