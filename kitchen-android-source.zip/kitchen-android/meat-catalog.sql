begin;
create table if not exists public.majd_meat_catalog (
 owner uuid not null references auth.users(id) on delete cascade,
 code text not null check (code ~ '^custom_(kg|n):.{1,60}$'),
 actor text not null check (char_length(btrim(actor)) between 1 and 80),
 recorded_at timestamptz not null default clock_timestamp(),
 primary key (owner, code)
);
alter table public.majd_meat_catalog enable row level security;
revoke all on public.majd_meat_catalog from public, anon, authenticated;
grant select on public.majd_meat_catalog to authenticated;
grant insert (owner, code, actor) on public.majd_meat_catalog to authenticated;
drop policy if exists majd_catalog_read on public.majd_meat_catalog;
create policy majd_catalog_read on public.majd_meat_catalog for select to authenticated using (auth.uid() = owner);
drop policy if exists majd_catalog_insert on public.majd_meat_catalog;
create policy majd_catalog_insert on public.majd_meat_catalog for insert to authenticated with check (auth.uid() = owner);
commit;
