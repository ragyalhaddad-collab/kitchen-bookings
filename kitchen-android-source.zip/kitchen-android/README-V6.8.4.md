# V6.8.4 — SMS
- Explicit SMS subscription only, independent of incoming SIM.
- Reject first, request SMS 2.5s later via internal receiver.
- Check full batch callbacks before counting daily success; all failed permits next call retry, partial/pending blocks duplicate.
- Legacy attempt-based history is not imported as confirmed success; a number successfully messaged on the older version may be messaged once again on upgrade day.
- Test SMS to a number entered by user (separate from daily automatic history).
- No booking or database schema changes.
- Android build and real network testing required.
