package com.majd.voicetest;
import android.content.*;
public class CallActions extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){VoiceService s=VoiceService.instance;if(s!=null)s.action(i.getAction());}
}
