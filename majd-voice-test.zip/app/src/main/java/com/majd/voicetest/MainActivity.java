package com.majd.voicetest;
import android.Manifest;
import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.telecom.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;
public class MainActivity extends Activity {
 LinearLayout root, accounts, manual; EditText dial; TextView status,log; MediaPlayer preview; Map<CheckBox,String> choices=new LinkedHashMap<>(); Handler h=new Handler(Looper.getMainLooper());
 final Runnable tick=new Runnable(){public void run(){refresh();h.postDelayed(this,1000);}};
 int burgundy=0xff701d35; int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff292322);t.setPadding(0,dp(6),0,dp(6));root.addView(t);return t;}
 Button button(LinearLayout box,String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->r.run());box.addView(b);return b;}
 boolean role(){return getSystemService(RoleManager.class).isRoleHeld(RoleManager.ROLE_DIALER);}
 @Override public void onCreate(Bundle b){super.onCreate(b);ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(dp(18),dp(18),dp(18),dp(18));root.setBackgroundColor(0xfffaf7ef);scroll.addView(root);setContentView(scroll);
 TextView title=text("مطبخ المجد | الرد الصوتي V2",23);title.setTextColor(burgundy);text("اختبار مستقل: يرد على كل متصل على الشرائح المحددة حتى إيقافه. لا يغيّر الحجوزات. استخدمه على هاتف المطبخ فقط، وليس هاتف الطوارئ.",15);
 status=text("",17);button(root,"1. تعيين التطبيق كهاتف افتراضي",()->{RoleManager rm=getSystemService(RoleManager.class);if(!role()&&rm.isRoleAvailable(RoleManager.ROLE_DIALER))startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER),20);else permissions();});button(root,"2. السماح بالصلاحيات وتحديث الشرائح",()->{permissions();loadAccounts();});
 text("3. اختر الشريحة أو الشريحتين",16);accounts=new LinearLayout(this);accounts.setOrientation(1);root.addView(accounts);loadAccounts();
 button(root,"استمع للتسجيل المعتمد",()->{if(preview!=null){preview.release();preview=null;}preview=MediaPlayer.create(this,R.raw.majd_voice);if(preview!=null){preview.start();preview.setOnCompletionListener(p->{p.release();preview=null;});}});
 button(root,"تفعيل خاصية نفاد الكمية",()->activate());button(root,"إيقاف خاصية نفاد الكمية",()->{Prefs.stop(this);if(VoiceService.instance!=null)VoiceService.instance.stopAutomatic();refresh();});
 text("التحكم اليدوي بالمكالمة الحالية",16);manual=new LinearLayout(this);manual.setOrientation(1);root.addView(manual);for(String[] a:new String[][]{{"رد","answer"},{"إنهاء","end"},{"مكبر الصوت","speaker"},{"سماعة الأذن","earpiece"},{"كتم / إلغاء الكتم","mute"}})button(manual,a[0],()->{if(VoiceService.instance!=null)VoiceService.instance.action(a[1]);});
 text("اتصال يدوي",16);dial=new EditText(this);dial.setInputType(InputType.TYPE_CLASS_PHONE);dial.setHint("رقم الاتصال");root.addView(dial);button(root,"اتصال",()->{if(!role()||checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){permissions();return;}String n=dial.getText().toString().trim();if(n.isEmpty())return;try{getSystemService(TelecomManager.class).placeCall(Uri.fromParts("tel",n,null),new Bundle());}catch(Exception e){toast("تعذر الاتصال");}});
 button(root,"استعادة تطبيق الهاتف الأصلي من الإعدادات",()->{Prefs.stop(this);if(VoiceService.instance!=null)VoiceService.instance.stopAutomatic();startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));});text("سجل التشخيص (محلي فقط)",16);log=text("",13);button(root,"مسح السجل",()->{Prefs.p(this).edit().remove("log").apply();refresh();});readDial(getIntent());}
 void readDial(Intent i){if(dial!=null&&i!=null&&i.getData()!=null&&"tel".equals(i.getData().getScheme()))dial.setText(i.getData().getSchemeSpecificPart());}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);readDial(i);}
 void permissions(){ArrayList<String> p=new ArrayList<>();for(String x:new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.CALL_PHONE})if(checkSelfPermission(x)!=PackageManager.PERMISSION_GRANTED)p.add(x);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),21);}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==20){permissions();loadAccounts();refresh();}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);loadAccounts();refresh();}
 void loadAccounts(){if(accounts==null)return;Set<String> selected=new HashSet<>();for(Map.Entry<CheckBox,String> e:choices.entrySet())if(e.getKey().isChecked())selected.add(e.getValue());if(choices.isEmpty())selected.addAll(Prefs.p(this).getStringSet("accounts",Collections.emptySet())); boolean first=selected.isEmpty()&&!Prefs.p(this).contains("accounts")&&choices.isEmpty();accounts.removeAllViews();choices.clear();try{TelecomManager tm=getSystemService(TelecomManager.class);for(PhoneAccountHandle handle:tm.getCallCapablePhoneAccounts()){PhoneAccount a=tm.getPhoneAccount(handle);if(a==null||!a.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION))continue;CheckBox cb=new CheckBox(this);cb.setText(a.getLabel()+" ("+(choices.size()+1)+")");String key=Prefs.key(handle);cb.setChecked(first||selected.contains(key));choices.put(cb,key);accounts.addView(cb);}}catch(Exception e){}if(choices.isEmpty()){TextView t=new TextView(this);t.setText("لم تظهر الشرائح: عيّن التطبيق كهاتف افتراضي وامنح الصلاحيات ثم حدّث.");accounts.addView(t);}}
 void activate(){if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED){toast("امنح صلاحية الهاتف ثم أعد التفعيل");permissions();return;}if(!role()){toast("عيّن التطبيق كهاتف افتراضي أولًا");return;}if(!getSystemService(NotificationManager.class).areNotificationsEnabled()){toast("فعّل إشعارات التطبيق أولًا");permissions();return;}Set<String> keys=new HashSet<>();for(Map.Entry<CheckBox,String> e:choices.entrySet())if(e.getKey().isChecked())keys.add(e.getValue());if(keys.isEmpty()){toast("اختر شريحة واحدة على الأقل");return;}Prefs.p(this).edit().remove("number").remove("until").putStringSet("accounts",keys).putBoolean("enabled_v2",true).apply();Prefs.log(this,"تم تفعيل الرد الصوتي لجميع المتصلين على الشرائح المختارة: "+keys.size()+"");refresh();}
 void refresh(){if(status==null||log==null)return;boolean active=role()&&Prefs.enabled(this);status.setText((role()?"الهاتف الافتراضي: المجد":"الهاتف الافتراضي: غير مفعل")+"\n"+(active?"نفدت الكمية • الرد الصوتي مفعّل":"الحجز متاح • الرد الصوتي متوقف"));status.setTextColor(active?0xffb91c1c:0xff166534);log.setText(Prefs.p(this).getString("log","لا يوجد سجل بعد"));if(manual!=null)manual.setVisibility(VoiceService.instance!=null&&VoiceService.instance.current()!=null?View.VISIBLE:View.GONE);}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 @Override protected void onResume(){super.onResume();refresh();h.removeCallbacks(tick);h.post(tick);}
 @Override protected void onPause(){super.onPause();h.removeCallbacks(tick);if(preview!=null){preview.release();preview=null;}}
}
