package com.majd.voicetest;
import android.content.*;
import android.telecom.*;
import android.telephony.PhoneNumberUtils;
import java.util.*;
import java.text.*;
final class Prefs {
 static SharedPreferences p(Context c){return c.getSharedPreferences("voice_test",0);}
 static String key(PhoneAccountHandle h){return h==null?"":h.getComponentName().flattenToString()+":"+h.getId();}
 static boolean enabled(Context c){return p(c).getBoolean("enabled_v2",false);}
 static void stop(Context c){p(c).edit().putBoolean("enabled_v2",false).remove("until").apply();}
 static void log(Context c,String s){String line=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date())+"  "+s;String old=p(c).getString("log","");String out=line+"\n"+old;p(c).edit().putString("log",out.substring(0,Math.min(out.length(),4000))).apply();}
 static String reason(Context c,Call call){
  if(!enabled(c))return "الرد الآلي متوقف";
  if(call.getState()!=Call.STATE_RINGING)return "المكالمة ليست في حالة الرنين";
  Call.Details d=call.getDetails();
  if(d==null||d.getAccountHandle()==null)return "لم يحدد النظام شريحة المكالمة بعد";
  if(!p(c).getStringSet("accounts",Collections.emptySet()).contains(key(d.getAccountHandle())))return "المكالمة على شريحة غير محددة";
  return "";
 }
 static boolean matches(Context c,Call call){return reason(c,call).isEmpty();}
}
