package com.majd.voicetest;
import android.content.*;
import android.telecom.*;
import android.telephony.PhoneNumberUtils;
import java.util.*;
import java.text.*;
final class Prefs {
 static SharedPreferences p(Context c){return c.getSharedPreferences("voice_test",0);}
 static String key(PhoneAccountHandle h){return h==null?"":h.getComponentName().flattenToString()+":"+h.getId();}
 static boolean enabled(Context c){long now=System.currentTimeMillis();return p(c).getLong("until",0)>now && p(c).getLong("until",0)-now<=900000;}
 static void stop(Context c){p(c).edit().putLong("until",0).apply();}
 static void log(Context c,String s){String line=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date())+"  "+s;String old=p(c).getString("log","");String out=line+"\n"+old;p(c).edit().putString("log",out.substring(0,Math.min(out.length(),4000))).apply();}
 static boolean matches(Context c,Call call){if(!enabled(c)||call.getState()!=Call.STATE_RINGING)return false;Call.Details d=call.getDetails();if(d==null||d.getHandle()==null||!"tel".equals(d.getHandle().getScheme()))return false;String number=d.getHandle().getSchemeSpecificPart();String test=p(c).getString("number","");if(test.length()<7||number==null||!PhoneNumberUtils.compare(number,test))return false;return p(c).getStringSet("accounts",Collections.emptySet()).contains(key(d.getAccountHandle()));}
}
