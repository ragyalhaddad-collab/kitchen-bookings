package com.majd.voicetest;
import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.telecom.*;
import java.util.*;
public class VoiceService extends InCallService {
 static VoiceService instance;
 private final Handler h=new Handler(Looper.getMainLooper());
 private final Map<Call,Call.Callback> callbacks=new HashMap<>();
 private final Set<Call> scheduled=new HashSet<>(), attempted=new HashSet<>();
 private final Map<Call,String> lastReason=new HashMap<>();
 private Call automatic; private MediaPlayer player; private boolean playing; private boolean routeRequested;
 @Override public void onCreate(){super.onCreate();instance=this;channel();}
 private void channel(){NotificationChannel ch=new NotificationChannel("calls","مكالمات التجربة",NotificationManager.IMPORTANCE_HIGH);ch.setSound(null,null);getSystemService(NotificationManager.class).createNotificationChannel(ch);}
 Call current(){for(Call c:getCalls())if(c.getState()==Call.STATE_RINGING)return c;for(Call c:getCalls())if(c.getState()==Call.STATE_ACTIVE)return c;for(Call c:getCalls())if(c.getState()!=Call.STATE_DISCONNECTED)return c;return null;}
 @Override public void onCallAdded(Call c){super.onCallAdded(c);Call.Callback cb=new Call.Callback(){@Override public void onStateChanged(Call call,int state){changed(call);}@Override public void onDetailsChanged(Call call,Call.Details d){changed(call);}};callbacks.put(c,cb);c.registerCallback(cb,h);changed(c);}
 @Override public void onCallRemoved(Call c){Call.Callback cb=callbacks.remove(c);if(cb!=null)c.unregisterCallback(cb);scheduled.remove(c);attempted.remove(c);lastReason.remove(c);if(automatic==c){cleanup();Prefs.log(this,"انتهت المكالمة");}super.onCallRemoved(c);notifyCall();}
 private boolean alone(Call c){for(Call x:getCalls())if(x!=c&&x.getState()!=Call.STATE_DISCONNECTED&&x.getState()!=Call.STATE_DISCONNECTING)return false;return true;}
 private void changed(Call c){notifyCall();if(c==automatic){if(c.getState()==Call.STATE_ACTIVE&&!routeRequested){routeRequested=true;try{setMuted(false);setAudioRoute(CallAudioState.ROUTE_SPEAKER);Prefs.log(this,"تم الرد - طلب مكبر الصوت");}catch(Exception e){fail("تعذر تشغيل مكبر الصوت");return;}h.postDelayed(()->beginWhenRouted(c,0),800);}if(c.getState()==Call.STATE_DISCONNECTED||c.getState()==Call.STATE_DISCONNECTING)cleanup();return;}
 if(c.getState()!=Call.STATE_RINGING)return;
 String reason=Prefs.reason(this,c);
 if(automatic!=null||!alone(c))reason="مكالمة أخرى جارية؛ لن يتم الرد الآلي";
 if(!reason.isEmpty()){
  if(!reason.equals(lastReason.put(c,reason)))Prefs.log(this,"مكالمة واردة: "+reason);
  return;
 }
 if(attempted.contains(c)||!scheduled.add(c))return;
 Prefs.log(this,"مكالمة واردة على شريحة مختارة - الرد بعد ثانيتين");
 h.postDelayed(()->{
  if(!scheduled.remove(c))return;
  if(!getCalls().contains(c)||automatic!=null||!alone(c)||!Prefs.matches(this,c)){
   Prefs.log(this,"أُلغي الرد قبل فتح الخط: "+Prefs.reason(this,c));return;
  }
  attempted.add(c);automatic=c;routeRequested=false;
  try{Prefs.log(this,"إرسال أمر فتح الخط تلقائيًا");c.answer(VideoProfile.STATE_AUDIO_ONLY);
   h.postDelayed(()->{if(automatic==c&&c.getState()==Call.STATE_RINGING&&Prefs.enabled(this)&&alone(c)){
    try{Prefs.log(this,"ما زال الخط يرن - إعادة محاولة الرد مرة واحدة");c.answer(VideoProfile.STATE_AUDIO_ONLY);}catch(Exception e){fail("تعذر إعادة الرد: "+e.getClass().getSimpleName());}
   }},3000);
   h.postDelayed(()->{if(automatic==c&&!routeRequested)fail("لم يؤكد النظام فتح الخط خلال 10 ثوان");},10000);
  }catch(Exception e){fail("تعذر الرد: "+e.getClass().getSimpleName());}
 },2000);
 }
 private void beginWhenRouted(Call c,int tries){if(automatic!=c||playing||c.getState()!=Call.STATE_ACTIVE)return;if(!Prefs.enabled(this)){fail("أوقف المستخدم الرد الآلي");return;}CallAudioState state=getCallAudioState();if(state==null||state.getRoute()!=CallAudioState.ROUTE_SPEAKER){if(tries<5){h.postDelayed(()->beginWhenRouted(c,tries+1),500);return;}fail("لم يتأكد توجيه الصوت إلى السبيكر");return;}
 try{player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());try(android.content.res.AssetFileDescriptor fd=getResources().openRawResourceFd(R.raw.majd_voice)){player.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());}player.setOnCompletionListener(p->{if(automatic==c){Prefs.log(this,"اكتمل تشغيل الملف - لم يتم التحقق من سماع المتصل");cleanup();c.disconnect();}});player.setOnErrorListener((p,w,e)->{fail("تعذر تشغيل التسجيل");return true;});player.setOnPreparedListener(p->{if(automatic!=c||c.getState()!=Call.STATE_ACTIVE)return;try{p.start();playing=true;Prefs.log(this,"بدأ تشغيل التسجيل");h.postDelayed(()->{if(automatic==c)fail("انتهت مهلة التشغيل");},25000);}catch(Exception e){fail("تعذر بدء الصوت");}});player.prepareAsync();h.postDelayed(()->{if(automatic==c&&!playing)fail("انتهت مهلة تجهيز الصوت");},8000);}catch(Exception e){fail("فشل تجهيز التسجيل");}}
 private void fail(String reason){Call c=automatic;Prefs.log(this,reason);cleanup();if(c!=null&&c.getState()==Call.STATE_ACTIVE){try{c.disconnect();Prefs.log(this,"أُغلق الخط بعد تعذر إكمال الرد");}catch(Exception e){Prefs.log(this,"تعذر إغلاق الخط؛ أنهه يدويًا");}}notifyCall();}
 private void cleanup(){if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}automatic=null;playing=false;routeRequested=false;}
 void stopAutomatic(){Prefs.stop(this);scheduled.clear();if(automatic!=null)fail("أوقف المستخدم التجربة");}
 void action(String a){Call c=current();if(c==null)return;try{switch(a){case "answer":scheduled.remove(c);attempted.add(c);if(automatic==c)cleanup();if(c.getState()==Call.STATE_RINGING)c.answer(VideoProfile.STATE_AUDIO_ONLY);break;case "end":scheduled.remove(c);attempted.add(c);cleanup();c.disconnect();break;case "speaker":setAudioRoute(CallAudioState.ROUTE_SPEAKER);break;case "earpiece":setAudioRoute(CallAudioState.ROUTE_EARPIECE);break;case "mute":CallAudioState st=getCallAudioState();setMuted(st!=null&&!st.isMuted());break;}}catch(Exception e){Prefs.log(this,"تعذر تنفيذ التحكم اليدوي");}}
 private PendingIntent actionIntent(String a,int code){return PendingIntent.getBroadcast(this,code,new Intent(this,CallActions.class).setAction(a),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 private void notifyCall(){NotificationManager nm=getSystemService(NotificationManager.class);Call c=current();if(c==null){nm.cancel(101);return;}boolean ring=c.getState()==Call.STATE_RINGING;Intent i=new Intent(this,MainActivity.class).putExtra("call_ui",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent pi=PendingIntent.getActivity(this,100,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=new Notification.Builder(this,"calls").setSmallIcon(android.R.drawable.sym_call_incoming).setContentTitle(ring?"مكالمة واردة":"مكالمة جارية").setContentText(ring&&Prefs.matches(this,c)&&alone(c)&&!attempted.contains(c)?"الرد الآلي مفعّل - سيتم فتح الخط":"المجد - تحكم بالمكالمة").setCategory(Notification.CATEGORY_CALL).setOngoing(true).setContentIntent(pi).setVisibility(Notification.VISIBILITY_PRIVATE);if(ring){b.setFullScreenIntent(pi,true);b.addAction(new Notification.Action.Builder(null,"رد",actionIntent("answer",1)).build());}b.addAction(new Notification.Action.Builder(null,"إنهاء",actionIntent("end",2)).build());try{nm.notify(101,b.build());}catch(Exception ignored){}}
 @Override public void onDestroy(){cleanup();h.removeCallbacksAndMessages(null);for(Map.Entry<Call,Call.Callback> e:callbacks.entrySet())e.getKey().unregisterCallback(e.getValue());callbacks.clear();getSystemService(NotificationManager.class).cancel(101);instance=null;super.onDestroy();}
}
