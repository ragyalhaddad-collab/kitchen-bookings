package com.majd.kitchen;
import android.app.*;import android.content.*;import android.media.*;import android.net.Uri;import android.os.*;import org.json.*;import java.util.*;
public class AlarmService extends Service {
 static boolean running=false;MediaPlayer player;Set<String> active=new HashSet<>();
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onCreate(){super.onCreate();running=true;}
 @Override public int onStartCommand(Intent i,int f,int id){AlarmQueue.daily(this);AlarmQueue.scheduleNext(this);LinkedHashMap<String,List<JSONObject>> g=AlarmQueue.groups(this);if(g.isEmpty()){stopForeground(true);stopSelf();return START_NOT_STICKY;}Set<String> now=new HashSet<>();for(List<JSONObject> l:g.values())now.addAll(AlarmQueue.keys(l));boolean added=!active.containsAll(now);active=now;try{startForeground(AlarmQueue.NOTIF,AlarmQueue.notification(this,g,false));}catch(Exception e){AlarmQueue.fallback(this);stopSelf();return START_NOT_STICKY;}if(added&&(player==null||!player.isPlaying()))playOnce();return START_STICKY;}
 void playOnce(){stopTone();String sound=Bookings.sound(this);if(sound.isEmpty())return;try{player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());player.setDataSource(this,Uri.parse(sound));player.setLooping(false);player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.prepare();player.start();}catch(Exception e){stopTone();}}
 void stopTone(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}}
 @Override public void onDestroy(){running=false;stopTone();super.onDestroy();}
}
