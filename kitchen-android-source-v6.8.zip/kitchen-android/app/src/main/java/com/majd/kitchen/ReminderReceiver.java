package com.majd.kitchen;
import android.content.*;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if("ack".equals(i.getAction())){AlarmQueue.advance(c,i.getStringExtra("key"));return;}AlarmQueue.kick(c);}
}
