package com.majd.kitchen;
import org.json.*;
public class OrderLinesTest {
 static void eq(String actual,String expected){if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
 public static void main(String[] args)throws Exception{
 JSONObject a=OrderLines.line("45 مجوز مع 400 جرام لحمة","45","");
 eq(a.optString("description"),"مجوز مع 400 جرام لحمة");eq(OrderLines.subtotal(a).toPlainString(),"45.00");eq(OrderLines.priceInput(a),"");
 JSONObject b=OrderLines.line("٥ × مجوز نص جاجة","5","1");eq(b.optString("description"),"مجوز نص جاجة");
 eq(OrderLines.total(new JSONArray().put(a).put(b)).toPlainString(),"50.00");
 JSONObject c=OrderLines.line("مجوز لحمة","","");eq(OrderLines.quantityInput(c),"");eq(OrderLines.priceInput(c),"");eq(OrderLines.subtotal(c).toPlainString(),"0.00");
 eq(OrderLines.subtotal(OrderLines.line("مجوز","","25")).toPlainString(),"0.00");eq(OrderLines.subtotal(OrderLines.line("مجوز","5","0")).toPlainString(),"0.00");
 eq(OrderLines.clean("400 جرام لحمة","45"),"400 جرام لحمة");eq(OrderLines.clean("45.5 مجوز","45.5"),"مجوز");
 String summary=OrderLines.summary(new JSONArray().put(a).put(b).put(c));if(summary.contains("45 × 45")||!summary.contains("الكمية غير محددة"))throw new AssertionError(summary);
 try{OrderLines.line("مجوز","-1","1");throw new AssertionError("negative count");}catch(IllegalArgumentException expected){}
 System.out.println("Order line tests passed (14 checks)");
 }
}
